<!DOCTYPE html> <html>
    <head>
    <link rel="icon" href="icone.ico" />
        <meta charset="utf-8" />
        <title> Interface web du compteur connecté </title>
         <link rel="stylesheet" href="style.css" />
    </head>
        <entete>
        <nav>
                    <ul>
                        <li><a href="#" style="background:#F00000">Accueil</a></li>
                        <li><a href="Consommation.php">Consommation</a></li>
                        <li><a href="Electrovanne.php">Gestion de l'électrovanne</a></li>
                    </ul>
            <h1> Bienvenue sur l'interface web de votre compteur d'eau connecté </h1>
        </entete>
        </html>

